import React from 'react'
import cl from './MyRedButton.module.css'

export default function MyRedButton({children, onClick}) {
  return (
    <button onClick={onClick} className={cl.RedButton}>
        {children}
    </button>
  )
}
