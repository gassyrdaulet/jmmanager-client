import React from 'react'
import cl from './MyInput.module.css'

function MyInput({type, placeholder, value, onChange}) {
  return (
    <input onChange={onChange} className={cl.MyInput} type={type} placeholder={placeholder} value={value} />
  )
}

export default MyInput