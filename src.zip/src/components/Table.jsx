import React from 'react'
import TableLine from './TableLine'
import cl from './Table.module.css'

export default function Table({data, heads}) {
    return (
        <div className={cl.TableWrapper}>
            <table className={cl.Table}>
                <thead>
                    <tr>
                        {heads.map((head) => <th key={head}>{head}</th>)}
                    </tr>
                </thead>
                <tbody>
                    {data.map((dataElement, index) => <TableLine data={dataElement} index={index} key={index}></TableLine>)}
                </tbody>
            </table>
        </div>
  )
}
