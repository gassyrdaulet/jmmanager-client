import cl from './NavBar.module.css'
import React, {useContext} from 'react';
import {useNavigate} from "react-router-dom";
import {AuthContext} from "../context";
import MyRedButton from '../UI/MyRedButton';

export default function NavBar() {
  const router = useNavigate()
  const {isAuth, setIsAuth} = useContext(AuthContext)

  const logout = () => {
      setIsAuth(false)
      localStorage.removeItem('auth')
      router('/login')
  }

  return (
    <div className={cl.navBarWrapper}>
      <div className={cl.navBar}>
          <div className={cl.navBarItemsLeft}>
            JackMarket.KZ
          </div>
          <div className={cl.navBarItemsRight}>
            {isAuth?
            <div className={cl.navBarItemsLeftWrapper}>
              <div className={cl.Profile}>
                {/* <p>{localStorage.getItem('name')}</p> */}
                <p>Gassyrdaulet</p>
                <MyRedButton onClick={logout}>Выйти</MyRedButton>
              </div>
            </div>
              :
              <span/>}
          </div>
      </div>
    </div>
  )
}
