import React from 'react'
import cl from './TableLine.module.css'

export default function TableLine({data, index}) {
    const dataArray = Object.values(data)

    return (
        <tr className={cl.Tr}>
            <td>{index+1}</td>
            {dataArray.map((dataElement, index) => <td key={index}>{dataElement}</td>)}
        </tr>
    )
}
