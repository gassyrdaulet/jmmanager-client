import React , {useState} from 'react'
import Loading from '../UI/Loading'
import refreshImage from '../img/refresh.png'
import cl from './Tabs.module.css'

export default function Tabs({children}) {
    const [toggleState, setToggleState] = useState(1)
    const toggleTab = (index) => { setToggleState(index) }
    
    return (
        <div className={cl.TabsWrapper}>
            <div className={cl.TabsHeader}>
                <div className={cl.TabsSlider}>
                    <div className={cl.Tabs}>
                        {children.map((child) => 
                        <div className={toggleState === parseInt(child.props.id)? cl.Tab + ' ' + cl.isActive : cl.Tab} onClick={() => toggleTab(parseInt(child.props.id))} key={child.props.id}>{child.props.tabname}</div>)}
                    </div>
                </div>
                <div className={cl.Refresh}><img src={refreshImage} alt='Обн.' /></div>
            </div>
            <div className={cl.TabsContents}>
                <div className={cl.TabsContent}>
                    {children[toggleState-1]}
                </div>
            </div>
        </div>
    )
}
