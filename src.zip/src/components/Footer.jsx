import React from 'react'
import cl from './Footer.module.css'

export default function footer() {
  return (
    <div className={cl.Footer}>2022 JackMarket.KZ Ⓒ</div>
  )
}
