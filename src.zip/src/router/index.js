import Error from "../Pages/Error";
import Login from "../Pages/Login";
import Main from "../Pages/Main";
import {Navigate} from "react-router-dom";

export const adminRoutes = [
    {path: '/' , element: <Error></Error>}
]
export const userRoutes = [
    {path: '/main' , element: <Main></Main>},
    {path: '/error' , element: <Error></Error>},
    {path: '/login' , element: <Navigate to='/main'></Navigate>},
    {path: '/' , element: <Navigate to='/main'></Navigate>},
    {path: '/*' , element: <Navigate to='/error'></Navigate>}
]
export const publicRoutes = [
    {path: '/login' , element: <Login></Login>},
    {path: '/error' , element: <Error></Error>},
    {path: '/*' , element: <Navigate to='/login'></Navigate>}
]