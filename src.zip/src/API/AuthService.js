import axios from "axios";


export default class Auth{
    static isTestingOnPhone = true
    static ip = '192.168.43.77'

    static async login (e, email, password, setIsAuth) {
        e.preventDefault()
        try{
          const data = await axios.post(Auth.isTestingOnPhone? 'http://'+Auth.ip+':5000/api/auth/login':'http://localhost:5000/api/auth/login', {
          email,
          password
        })
        if(data.data.token !== undefined){
          setIsAuth(true)
          localStorage.setItem('auth', 'true')
          localStorage.setItem('token', data.data.token)
          localStorage.setItem('email', data.data.user.email)
          localStorage.setItem('name', data.data.user.name)
          localStorage.setItem('id', data.data.user.id)
        }
        return data.data
        }catch(e){
          console.log(e)
        }
      } 
}