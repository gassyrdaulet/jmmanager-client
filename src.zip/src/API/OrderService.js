import axios from "axios";
import Auth from './AuthService'

axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('token')}`

export default class OrderService{
    static async getAllOrders() {
        const data = await axios.get('http://' + (Auth.isTestingOnPhone?Auth.ip:'localhost') + ':5000/api/orders/', 
        {   params:{
            status: 0,
            pickup: 0
            }
        })
        return data
    }
}