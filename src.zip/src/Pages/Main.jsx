import React from 'react'
import cl from './Main.module.css'
import {useState} from 'react'
import Tabs from '../components/Tabs'
import Loading from '../UI/Loading'
import Table from '../components/Table'
import OrderService from '../API/OrderService'

export default function Main() {
  const token = localStorage.getItem('token')
  const data = [
    {id: 1, title:'Gassyr1', description:'Hello'},
    {id: 2, title:'Gassyr2', description:'Hello'},
    {id: 3, title:'Gassyr3', description:'Hello'},
    {id: 4, title:'Gassyr4', description:'Hello'},
    {id: 5, title:'Gassyr5', description:'Hello'},
  ]
  const data2 = [
    {id: 1, title:'Gassyr1', description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ullam velit fugit, eum rem, ipsam quae laborum veniam dicta illum incidunt tenetur voluptatibus asperiores iste, nihil quasi? Sequi porro illo praesentium?', date:'yesterday'},
    {id: 2, title:'Gassyr1', description:'Hello', date:'yesterday'},
    {id: 3, title:'Gassyr1', description:'Hello', date:'yesterday'},
    {id: 4, title:'Gassyr1', description:'Hello', date:'yesterday'},
    {id: 5, title:'Gassyr1', description:'Hello', date:'yesterday'},
    {id: 5, title:'Gassyr1', description:'Hello', date:'yesterday'},
    {id: 5, title:'Gassyr1', description:'Hello', date:'yesterday'},
    {id: 5, title:'Gassyr1', description:'Hello', date:'yesterday'},
    {id: 5, title:'Gassyr1', description:'Hello', date:'yesterday'},
  ]
  
  console.log(OrderService.getAllOrders())
  return (
    <div className={cl.Main}>
      <Tabs>
          <div tabname= 'Новые' id='1'>
              <Table heads={["№",'Идентификатор',"Название товара от магазина или от меня или от кого то еще","Описание","Когда"]} data={data2}/>
          </div>
          <div tabname= 'Самовывоз' id='2'>
              <Table heads={["№",'Идентификатор',"Название","Описание"]} data={data}/>
          </div>
          <div tabname= 'Доставка' id='3'>
              <h2>Content 3</h2>
          </div>
          <div tabname= 'Цены' id='4'>
              <h2>Content 4</h2>
          </div>
          <div tabname= 'Архив' id='5'>
              <h2>Content 5</h2>
          </div>
      </Tabs>
    </div>
  )
}
