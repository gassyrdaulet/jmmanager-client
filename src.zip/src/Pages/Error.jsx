import React from 'react';
import {Link} from "react-router-dom";
import cl from './Error.module.css'

const Error = () => {
    return (
        <div className={cl.Error}>
            <h1>
                404
            </h1>
            <div>
                Страница не найдена
            </div>
            <Link className='Link' to='/'>
                Вернуться
            </Link>
        </div>
    );
};

export default Error;