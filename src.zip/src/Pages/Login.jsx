import React from 'react'
import cl from './Login.module.css'
import AuthService from '../API/AuthService'
import {useState, useContext} from 'react'
import MyButton from '../UI/MyButton'
import MyInput from '../UI/MyInput'
import {AuthContext} from "../context";

export default function Login() {    
    const [inputEmail, setInputEmail] = useState('')
    const [inputPassword, setInputPassword] = useState('')
    const {setIsAuth} = useContext(AuthContext)

    return (
        <div className={cl.Login}>
        <form className={cl.LoginForm}>
            <h1>ВОЙДИТЕ В АККАУНТ</h1>
            <MyInput onChange={(e)=>{setInputEmail(e.target.value)}} type='text' placeholder="Эл. почта" value={inputEmail}/>
            <MyInput onChange={(e)=>{setInputPassword(e.target.value)}}type='password' placeholder="Пароль" value={inputPassword}/>
            <MyButton onClick={(e)=>{AuthService.login(e,inputEmail,inputPassword,setIsAuth)}}>Войти</MyButton>
        </form>
        {/* <div className={cl.Background}>
                <h2>Welcome.</h2>
            </div> */}
        </div>
    )
}
